﻿namespace QuanLyQuanCafe.Models
{
    public class Quanlydonhang
    {
    }
}
